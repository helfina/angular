import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ProductsService } from '../services/products.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private ps: ProductsService) { }

  addProduct(form: NgForm){
    // console.log(form.value);
    this.ps.createProduct(form.value);
    console.log(sessionStorage.getItem("products"));

  }

  ngOnInit(): void {
  }

}
