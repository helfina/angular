import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  categories= Array();
  cats : any;

  createCategory(category : Object){

     if(  ! sessionStorage.getItem('categories'))
      {
      
        let newCategory= { id:1, ... category    };
         //console.log(newCategory);
         this.categories=[];
         this.categories.push(newCategory);
         sessionStorage.setItem('categories', JSON.stringify(this.categories));

      }else{

      this.cats=sessionStorage.getItem('categories');
      this.categories=JSON.parse(this.cats);
       let id = this.categories.slice(-1)[0]['id'] + 1;
       let newCategory= { id:id, ... category    };
      this.categories.push(newCategory);
      sessionStorage.setItem('categories', JSON.stringify(this.categories));

     }
    
  }

  readCategories(){

    this.cats=sessionStorage.getItem('categories');
     return this.categories=JSON.parse(this.cats);

  }


  constructor() { }
}
